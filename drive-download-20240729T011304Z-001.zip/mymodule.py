def greeting(name):
  print("Hello, " + name)
  if __name__ == '__main__':
     print ("Hello, Everybody")

person1 = {
  "name": "John",
  "age": 36,
  "country": "Norway"
}

